package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class InventoryManager extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    public InventoryManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, item_name TEXT, quantity INTEGER)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS inventory");
        onCreate(db);
    }

    public boolean addItem(String itemName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item_name", itemName);
        values.put("quantity", quantity);

        long result = db.insert("inventory", null, values);
        db.close();

        return result != -1; // Returns true if insert was successful
    }

    public boolean updateItemQuantity(String itemName, int newQuantity) { // FIXED METHOD NAME
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("quantity", newQuantity);

        int rowsAffected = db.update("inventory", values, "item_name = ?", new String[]{itemName});
        db.close();

        return rowsAffected > 0; // Returns true if at least one row was updated
    }

    public boolean deleteItem(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete("inventory", "item_name = ?", new String[]{itemName});
        db.close();

        return rowsDeleted > 0; // Returns true if at least one row was deleted
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM inventory", null);
    }
}

