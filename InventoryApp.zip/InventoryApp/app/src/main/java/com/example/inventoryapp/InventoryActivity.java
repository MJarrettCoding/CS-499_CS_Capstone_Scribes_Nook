package com.example.inventoryapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 2;

    private InventoryManager inventoryManager;
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private List<InventoryItem> inventoryList;
    private EditText editTextItemName, editTextItemQuantity;
    private Button addItemButton, updateItemButton, deleteItemButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);

        if (!isLoggedIn) {
            // Redirect to login if user is not logged in
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        }

        setContentView(R.layout.activity_inventory);

        inventoryManager = new InventoryManager(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        editTextItemName = findViewById(R.id.editTextItemName);
        editTextItemQuantity = findViewById(R.id.editTextItemQuantity);
        addItemButton = findViewById(R.id.btnAddItem);
        updateItemButton = findViewById(R.id.btnUpdateItem);
        deleteItemButton = findViewById(R.id.btnDeleteItem);

        inventoryList = new ArrayList<>();
        adapter = new InventoryAdapter(inventoryList);
        recyclerView.setAdapter(adapter);

        loadInventory();

        addItemButton.setOnClickListener(v -> addItem());
        updateItemButton.setOnClickListener(v -> updateItem());
        deleteItemButton.setOnClickListener(v -> deleteItem());

        // Request SMS permission if not already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    private void addItem() {
        String itemName = editTextItemName.getText().toString().trim();
        String quantityStr = editTextItemQuantity.getText().toString().trim();

        if (itemName.isEmpty() || quantityStr.isEmpty()) {
            Toast.makeText(this, "Please enter both name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity = Integer.parseInt(quantityStr);
        boolean inserted = inventoryManager.addItem(itemName, quantity);

        if (inserted) {
            Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show();
            editTextItemName.setText("");
            editTextItemQuantity.setText("");
            loadInventory();
        } else {
            Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateItem() {
        String itemName = editTextItemName.getText().toString().trim();
        String quantityStr = editTextItemQuantity.getText().toString().trim();

        if (itemName.isEmpty() || quantityStr.isEmpty()) {
            Toast.makeText(this, "Please enter both name and new quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int newQuantity = Integer.parseInt(quantityStr);
        boolean updated = inventoryManager.updateItemQuantity(itemName, newQuantity); // FIXED METHOD NAME

        if (updated) {
            Toast.makeText(this, "Item updated successfully!", Toast.LENGTH_SHORT).show();
            editTextItemName.setText("");
            editTextItemQuantity.setText("");
            loadInventory();
        } else {
            Toast.makeText(this, "Failed to update item", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteItem() {
        String itemName = editTextItemName.getText().toString().trim();

        if (itemName.isEmpty()) {
            Toast.makeText(this, "Please enter an item name to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean deleted = inventoryManager.deleteItem(itemName);

        if (deleted) {
            Toast.makeText(this, "Item deleted successfully!", Toast.LENGTH_SHORT).show();
            editTextItemName.setText("");
            editTextItemQuantity.setText("");
            loadInventory();
        } else {
            Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadInventory() {
        inventoryList.clear();
        Cursor cursor = inventoryManager.getAllItems();
        while (cursor.moveToNext()) {
            @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("item_name"));
            @SuppressLint("Range") int quantity = cursor.getInt(cursor.getColumnIndex("quantity"));
            inventoryList.add(new InventoryItem(name, quantity));

            // Check for low stock and send notification if applicable
            if (quantity <= 3) {
                sendSMSNotification(name, quantity);
            }
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private void sendSMSNotification(String itemName, int quantity) {
        String phoneNumber = "1234567890"; // Replace with actual recipient number
        String message = "Low stock alert: " + itemName + " is at " + quantity + " units!";

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "Low stock alert sent for " + itemName, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "SMS permission not granted. Cannot send low stock alerts.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadInventory(); // Recheck inventory after permission is granted
            } else {
                Toast.makeText(this, "SMS Permission Denied. Notifications disabled.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}



